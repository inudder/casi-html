
        <?php get_template_part('amp/partials/footer'); ?>

        <div class="clear"></div>
    </div>
    <!-- end: #wrapper --> 

    <?php wp_footer(); ?>

    </body>
</html>
